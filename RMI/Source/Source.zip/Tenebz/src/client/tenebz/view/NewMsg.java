/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client.tenebz.view;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JPanel;
import middle.tenebz.beans.Message;

/**
 *
 * @author TOURE
 */
public class NewMsg extends JPanel {

    private javax.swing.JLabel authorLbl;
    private javax.swing.JLabel msgLbl;
    private javax.swing.JLabel pseudoLbl;
    private javax.swing.JButton sendBtn;
    private javax.swing.JLabel timeLbl;

    public NewMsg(Message msg) {
        authorLbl = new javax.swing.JLabel();
        msgLbl = new javax.swing.JLabel();
        //msgLbl.setLineWrap(true);
        timeLbl = new javax.swing.JLabel();
        sendBtn = new javax.swing.JButton();
        pseudoLbl = new javax.swing.JLabel();             
        this.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        authorLbl.setText(msg.getClient().getPseudo());
        msgLbl.setText(msg.getContenu());
        msgLbl.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        timeLbl.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        timeLbl.setText(formatter(msg.getDate()));
        javax.swing.GroupLayout newMsgPanLayout = new javax.swing.GroupLayout(this);
        this.setLayout(newMsgPanLayout);
        newMsgPanLayout.setHorizontalGroup(
            newMsgPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(newMsgPanLayout.createSequentialGroup()
                .addComponent(authorLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(timeLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(newMsgPanLayout.createSequentialGroup()
                .addComponent(msgLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 487, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        newMsgPanLayout.setVerticalGroup(
            newMsgPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(newMsgPanLayout.createSequentialGroup()
                .addGroup(newMsgPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(authorLbl)
                    .addComponent(timeLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(msgLbl)
                .addContainerGap())
        );        
    }
    
    public static String formatter(Date dt) {
        SimpleDateFormat df = new SimpleDateFormat("EEEE, d MMMM yyyy 'à' hh:mm");
        return df.format(dt);
    }
}
