package client.tenebz.core;


import client.tenebz.view.AuthView;
import static client.tenebz.view.AuthView.ErrorMsg;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import middle.tenebz.io.TenebzIO;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author TOURE
 */
public class TenebzClient {
    
    public static void main(String[] args) throws RemoteException {
        ClientIOImp clientIOImp = new ClientIOImp();
        connectServer(clientIOImp);
        if(clientIOImp.getServer() == null) {
            ErrorMsg("Impossible de se connecter au serveur");
        } else {
            (new AuthView(clientIOImp)).view();            
        }
    }

    public static boolean connectServer(ClientIOImp clientIOImp) {
        try {
            Registry reg = LocateRegistry.getRegistry("localhost", 1099);
            TenebzIO server = (TenebzIO) reg.lookup("serveur");
            clientIOImp.setServer(server);
            System.out.println("Connecté au serveur");
            return true;
        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
    }
}
