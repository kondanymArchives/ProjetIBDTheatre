/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package client.tenebz.core;

import middle.tenebz.io.ClientIO;
import client.tenebz.view.ChatView;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import middle.tenebz.beans.Client;
import middle.tenebz.beans.Message;
import middle.tenebz.io.TenebzIO;

/**
 *
 * @author TOURE
 */
public class ClientIOImp extends UnicastRemoteObject implements ClientIO {
    
    private Client client;
    private ChatView chat;
    private TenebzIO server;

    public ClientIOImp() throws RemoteException {
        client = null;
        chat = null;
        server = null;
    }
    
    public ClientIOImp(Client client, ChatView chat, TenebzIO server) throws RemoteException {
        this.client = client;
        this.chat = chat;
        this.server = server;
    }

    @Override
    public void receive(Message msg) throws RemoteException {
        chat.afficher(msg);
    }

    @Override
    public Client getClient() throws RemoteException {
        return client;
    }    

    public ChatView getChat() {
        return chat;
    }

    public void setChat(ChatView chat) {
        this.chat = chat;
    }

    public TenebzIO getServer() {
        return server;
    }

    public void setServer(TenebzIO server) {
        this.server = server;
    }

    public void setClient(Client client) {
        this.client = client;
    }
}
