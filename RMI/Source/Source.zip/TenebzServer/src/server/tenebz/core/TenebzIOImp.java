/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package server.tenebz.core;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.rmi.RemoteException;
import middle.tenebz.beans.Message;
import java.rmi.server.*;
import java.util.ArrayList;
import java.util.List;
import middle.tenebz.beans.Client;
import middle.tenebz.io.ClientIO;
import middle.tenebz.io.TenebzIO;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Date;

/**
 *
 * @author TOURE
 */
public class TenebzIOImp extends UnicastRemoteObject implements TenebzIO {

    private List<ClientIO> clients;
    private List<Client> registred;
    private List<Message> messages;

    public TenebzIOImp() throws RemoteException {
        super();
        clients = new ArrayList<ClientIO>();
        messages = new ArrayList<Message>();
        registred = new ArrayList<Client>();
    }

    @Override
    public boolean register(Client client) throws RemoteException {
        for (Client c : registred) {
            if (c.getPseudo().equals(client.getPseudo())) {
                return false;
            }
        }
        return registred.add(client);
    }

    @Override
    public boolean join(ClientIO client) throws RemoteException {
        for (Client c : registred) {
            if (c.getPseudo().equals(client.getClient().getPseudo())
                    && c.getPassword().equals(client.getClient().getPassword())) {
                return clients.add(client);
            }
        }
        return false;
    }

    @Override
    public void leave(ClientIO client) throws RemoteException {
        clients.remove(client);
    }

    @Override
    public void push(Message message) throws RemoteException {
        messages.add(message);
        broadcast(message);
    }

    @Override
    public void broadcast(Message message) throws RemoteException {
        for (ClientIO c : clients) {
            c.receive(message);
        }
    }

    @Override
    public List<Message> history() throws RemoteException {
        return messages;
    }

    public void load(String Fsave) {
        File f = new File(Fsave);
        try {
            FileReader Freader = new FileReader(f);
            BufferedReader in = new BufferedReader(Freader);
            String next = in.readLine();
            while( next.equals("#next")) {
            
            String client = in.readLine();
            String date = in.readLine();   
            String contenu = in.readLine();
             next = in.readLine();
            System.out.println(client);
             System.out.println(date);
             System.out.println(contenu);
             
            Client c = new Client(client,"");
            Date d = new Date(date);
            Message m = new Message(c,contenu,d);
            messages.add(m);
            }

            in.close();
            Freader.close();
        } catch (Exception ex) {
            System.out.println("Le fichier n'existe pas !!");
        }

    }

    public void save(String Fsave) {
        File f = new File(Fsave);
        try {
            FileWriter Fwriter = new FileWriter(f);
            BufferedWriter out = new BufferedWriter(Fwriter);
            for (Message m : messages) {
                
                out.write("#next" + "\n");
                out.write(m.getClient().getPseudo() + "\n");
                out.write(m.getDate().toString() + "\n");
                out.write(m.getContenu() + "\n");
            }
            out.write("#end" + "\n");
            out.close();
            Fwriter.close();
        } catch (Exception ex) {
            System.out.println("Erreur d'écriture !!");
        }
    }

}
