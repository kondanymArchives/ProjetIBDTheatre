/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package server.tenebz.core;

import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;
import server.tenebz.view.ServerView;


/**
 *
 * @author TOURE
 */
public class TenebzServer {

    public static void main(String[] arg) {
        (new ServerView(new TenebzServer())).view();
    }

    public TenebzIOImp t;
    private static String Fsave = "Fsave.tenebz";
    
    public boolean hosted() {
        System.out.println();
        try {
            t = new TenebzIOImp();
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.bind("serveur", t);
            System.out.println("Le serveur a demarré");
            t.load(Fsave);
            return true;
        } catch (Exception e) {
            System.out.println("Erreur: " + e.getMessage());
            return false;
        }
    }

    public void disconnect() throws RemoteException, NotBoundException {
        Registry registry = LocateRegistry.getRegistry(1099);
        t.save(Fsave);
        registry.unbind("serveur");
    }
    
 

}
